<?php
include_once('core/conexao.php');

$color_id = filter_var($_POST['usertarget'], FILTER_SANITIZE_NUMBER_INT);
$action_type = filter_var($_POST['acttp'], FILTER_SANITIZE_NUMBER_INT);

if ($action_type == 1) //aqui você faz o script que faz a função de reenviar o email para o usuário
{
    $sql_utilizador = mysqli_query($mysqli, "DELETE FROM color WHERE color_id=" . $color_id . "");
    $color_id = (object) array("color_id" => $color_id, "retorno" => 0, "nome" => "search:");
    echo json_encode($color_id);
}

if ($action_type == 2) //aqui você faz o script que te direciona pra página de edição de dados
{
    $color_id = (object) array("color_id" => $color_id, "retorno" => 1, "nome" => "search:");
    echo json_encode($color_id);
}
