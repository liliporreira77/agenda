<?php

// Incluir o arquivo com a conexão com banco de dados
include_once './conexao.php';


// Receber os dados enviado pelo JavaScript
$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);
// var_dump($dados);
$a = 0;


// Recuperar os dados das cores
$query_colors = "SELECT color_id, nome_tipo, color FROM color WHERE color_id=:color_id LIMIT 1";

// Prepara a QUERY
$result_colors = $conn->prepare($query_colors);


// Substituir o link pelo valor
$result_colors->bindParam(':color_id', $dados['edit_color_id']);

// Executar a QUERY
$result_colors->execute();

$row_colors = $result_colors->fetch(PDO::FETCH_ASSOC);

// Recuperar os dados do usuário no banco de dados
$query_user = "SELECT user_id, nome_login, email FROM login WHERE user_id =:user_id LIMIT 1";

// Prepara a QUERY
$result_user = $conn->prepare($query_user);

// Substituir o link pelo valor
$result_user->bindParam(':user_id', $dados['edit_user_id']);

// Executar a QUERY
$result_user->execute();

// Ler os dados do usuário
$row_user = $result_user->fetch(PDO::FETCH_ASSOC);

//Imagem

//Inserir anexos
$countfiles = count($_FILES['filesedit']['name']);
// Upload directory
$upload_location = "uploads/" . $dados['edit_user_id'] . "/";
if (!file_exists($upload_location)) {
    mkdir("uploads/" . $dados['edit_user_id']); //aqui ele irá criar a pasta
    $upload_location = "$upload_location/";
} else
    $upload_location = $upload_location;
// To store uploaded files path
$files_arr = array();
// Loop all files
for ($index = 0; $index < $countfiles; $index++) {
    if (isset($_FILES['filesedit']['name'][$index]) && $_FILES['filesedit']['name'][$index] != '') {

        // Recuperar os dados das cores
        $query_images = "SELECT id, image FROM events WHERE id=:id and image=:image LIMIT 1";

        // Prepara a QUERY
        $result_images = $conn->prepare($query_images);


        // Substituir o link pelo valor
        $result_images->bindParam(':id', $dados['id']);
        $result_images->bindParam(':image', $dados['edit_anexo']);

        // Executar a QUERY
        $result_images->execute();
        $antiga = $dados['edit_anexo'];
        if ($antiga!='') {
            unlink("$antiga");
        }
        // File name
        $filename = $_FILES['filesedit']['name'][$index];
        // Get extension
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        // Valid image extension
        $valid_ext = array("png", "jpeg", "jpg");
        // Check extension
        if (in_array($ext, $valid_ext)) {
            // File path
            $path = $upload_location . $filename;
            // Upload file
            if (move_uploaded_file($_FILES['filesedit']['tmp_name'][$index], $path)) {
                $files_arr[] = $path;
                $a = 1;
            }

        }
    }
}

if ($a == 1) {

    // Criar a QUERY editar evento no banco de dados
    $query_edit_event = "UPDATE events SET title=:title, start=:start, end=:end, obs=:obs, local=:local,color_id=:color_id, user_id=:user_id, image=:image WHERE id=:id";

    // Prepara a QUERY
    $edit_event = $conn->prepare($query_edit_event);

    // Substituir o link pelo valor
    $edit_event->bindParam(':title', $dados['edit_title']);
    $edit_event->bindParam(':start', $dados['edit_start']);
    $edit_event->bindParam(':end', $dados['edit_end']);
    $edit_event->bindParam(':obs', $dados['edit_obs']);
    $edit_event->bindParam(':local', $dados['edit_local']);
    $edit_event->bindParam(':color_id', $dados['edit_color_id']);
    $edit_event->bindParam(':user_id', $dados['edit_user_id']);
    $edit_event->bindParam(':id', $dados['edit_id']);
    $edit_event->bindParam(':image', $dados['filesedit']);

    // Verificar se consegui editar corretamente
    if ($edit_event->execute()) {

        $retorna = [
            'status' => true,
            'msg' => 'Evento editado com sucesso!',
            'id' => $dados['edit_id'],
            'title' => $dados['edit_title'],
            'start' => $dados['edit_start'],
            'end' => $dados['edit_end'],
            'obs' => $dados['edit_obs'],
            'user_id' => $row_user['user_id'],
            'nome_login' => $row_user['nome_login'],
            'color_id' => $row_colors['color_id'],
            'color' => $row_colors['color'],
            'nome_tipo' => $row_colors['nome_tipo'],
            'image' => $path,
        ];
    } else
        $retorna = ['status' => false, 'msg' => 'Erro: Evento não editado!'];
}
if ($a == 0) {
    // Criar a QUERY editar evento no banco de dados
    $query_edit_event = "UPDATE events SET title=:title, start=:start, end=:end, obs=:obs, local=:local, color_id=:color_id, user_id=:user_id WHERE id=:id";

    // Prepara a QUERY
    $edit_event = $conn->prepare($query_edit_event);

    // Substituir o link pelo valor
    $edit_event->bindParam(':title', $dados['edit_title']);
    $edit_event->bindParam(':start', $dados['edit_start']);
    $edit_event->bindParam(':end', $dados['edit_end']);
    $edit_event->bindParam(':obs', $dados['edit_obs']);
    $edit_event->bindParam(':local', $dados['edit_local']);
    $edit_event->bindParam(':color_id', $dados['edit_color_id']);
    $edit_event->bindParam(':user_id', $dados['edit_user_id']);
    $edit_event->bindParam(':id', $dados['edit_id']);

    // Verificar se consegui editar corretamente
    if ($edit_event->execute()) {

        $retorna = [
            'status' => true,
            'msg' => 'Evento editado com sucesso!',
            'id' => $dados['edit_id'],
            'title' => $dados['edit_title'],
            'start' => $dados['edit_start'],
            'end' => $dados['edit_end'],
            'obs' => $dados['edit_obs'],
            'local' => $dados['edit_local'],
            'user_id' => $row_user['user_id'],
            'nome_login' => $row_user['nome_login'],
            'color_id' => $row_colors['color_id'],
            'color' => $row_colors['color'],
            'nome_tipo' => $row_colors['nome_tipo'],
        ];
    } else
        $retorna = ['status' => false, 'msg' => 'Erro: Evento não editado!'];
}


// Converter o array em objeto e retornar para o JavaScript
echo json_encode($retorna);