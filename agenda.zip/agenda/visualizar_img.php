<?php
var_dump($dados);