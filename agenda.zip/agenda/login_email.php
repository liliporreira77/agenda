<div class="container content__boxed">
    <?php
	// includes do phpmail.
	include_once('core/conexao.php');
	include_once('core/config.php');

	use \PHPMailer\PHPMailer\PHPMailer;
	use \PHPMailer\PHPMailer\Exception;

	require 'PHPMailer/src/Exception.php';
	require 'PHPMailer/src/PHPMailer.php';
	require 'PHPMailer/src/SMTP.php';
	$mail = new PHPMailer(true);
	//Aqui é a página onde você vai criar o script que vai excluir, editar ou enviar o email

	//pega o id do usuário
	$userid = isset($_GET['userid']) ? $_GET['userid'] : '';
	$result = mysqli_query($mysqli, "SELECT nome_login, email FROM login WHERE num_mecanografico='" . $userid . "'");
	$row = mysqli_fetch_array($result);
	$email1 = $row['email'];
	$nome1 = $row['nome_login'];

	//Gera uma senha aleatória e única de aceuesso primário
	$senha_hash = mt_rand(1111, 9999);
	$senha_hash_md5 = md5($senha_hash);
	$hash_session = 0;
	//Reenvia o email usando o PHPMailer
	try {
		//Server settings
		$mail->SMTPDebug = \PHPMailer\PHPMailer\SMTP::DEBUG_OFF;  // Enable verbose debug output
		$mail->isSMTP();                                          // Send using SMTP

		$mail->Host = 'mail.multimeios.pt';                  // Set the SMTP server to send through
		$mail->CharSet = 'UTF-8';
		$mail->SMTPAuth = true;                           // Enable SMTP authentication
		$mail->SMTPSecure = 'tls';
		$mail->Username = 'contactos@espinho.pt';         // SMTP username
		$mail->Password = 'Ola123456';                      // SMTP password
		//$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;       // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
		$mail->Port = 587;                               // TCP port to connect to
		//Recipientsn
		$mail->setFrom($email1, $nome1);
		$mail->addAddress($email1, 'Base de dados Contactos - Recuperação da password');
		$mail->addReplyTo($email1, 'Information');
		// Content
		$mail->isHTML(true);                                       // Set email format to HTML
		$mail->Subject = ('Administrador de Contactos ');
		$mail->Body = str_replace(array('login_subst', 'nome_subst', 'senha_subst'), array($userid, $nome1, $senha_hash), file_get_contents('template/email/edit-user.html'));
		$mail->AltBody = 'Recuperação da password';
		$mail->send();
	} catch (Exception $e) {
		echo "Erro ao enviar mensagem: {$mail->ErrorInfo}";
	}
	$update_user = mysqli_query($mysqli, "UPDATE login SET password='" . $senha_hash_md5 . "', hash_session='" . $hash_session . "' WHERE num_mecanografico=" . $userid . "");


	?>
    <div id="divCenter">
        <div class="form-block">
            <h1>Reenvio da nova password <br> <br> </h1>
            <div id="alert-senha" aline="center" class="alert alert-success alert-dismissible show" role="alert">
                Foi enviado uma nova password. Verifique a sua caixa de e-mail por favor.</div>
        </div>
    </div>