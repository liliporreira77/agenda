<?php

require('core/config.php');
require('core/conexao.php');
$color_id = filter_var($_POST['usertarget'], FILTER_SANITIZE_NUMBER_INT);
$action_type = filter_var($_POST['acttp'], FILTER_SANITIZE_NUMBER_INT);

if ($action_type == 1) {
    $sql_u = mysqli_query($mysqli, "DELETE FROM events WHERE color_id=" . $color_id . "");
    $sql_c = mysqli_query($mysqli, "DELETE FROM color WHERE color_id=" . $color_id . "");
    $color_id = (object) array("color_id" => $color_id, "retorno" => 0, "nome" => "search:");
    echo json_encode($color_id);
}

if ($action_type == 2) {
    $color_id = (object) array("color_id" => $color_id, "retorno" => 1, "nome" => "search:");
    echo json_encode($color_id);
}
