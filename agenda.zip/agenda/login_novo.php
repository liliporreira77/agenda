 <?php
    //  
    //     verifica_nivel();

    ?>
 <div class="container content__boxed" style="text-align: center;">
     <div id="divCenter">
         <div class="form-block">
             <h1>Inserir Novo Utilizador <br> </h1>
             <h1> </h1>
             <form method="post" action="" id="novoregisto">
                 <div id="msg_num_mec"></div>
                 <div id="formfields">
                     <div class="form-itens">
                         <label for="num" class="form-itens">Número Mecanográfico: </label>
                         <input type="number" id="mecanografico" name="mecanografico" class="form-itens form-pequenos"
                             placeholder="Número mecanográfico" autofocus>
                     </div>
                     <div class="form-itens">
                         <label for="nome" class="form-itens">Nome: </label>
                         <input type="text" class="form-input" name="nome" id="nome"
                             placeholder="Insira o nome do funcionário">
                     </div>
                     <div class="form-itens">
                         <label for="email" class="form-itens">E-mail:
                         </label>
                         <input type="email" class="form-input" name="email" id="email"
                             placeholder="email@cm-espinho.pt">
                     </div>
                     <br><br>
                     <div class="labelbotton">
                         <input class="button-default form-submit" id="submit_new_user" type="button" value="Inserir">
                     </div>
                 </div>
             </form>
         </div>
     </div>
 </div>
 <script type="text/javascript">
$(document).ready(function() {


    //validação
    $('#submit_new_user').click(function() {
            var onivel_id = $('#utilizador').val();
            var omecanografico = $('#mecanografico').val();
            var oNome = $('#nome').val();
            var oemail = $('#email').val();
            $.ajax({
                url: "login_novo_actions.php",
                type: "POST",
                data: {
                    nome: oNome,
                    mecanografico: omecanografico,
                    email: oemail
                }
            }).done(function(data) {
                // console.log(data);

                //TUDO OK
                if (data == 0) //Existe
                {
                    $('#msg_num_mec').html(
                        '<div id="alert-senha" class="alert alert-success alert-dismissible show" role="alert">O tipo de utilizador foi inserido com sucesso!</div>'
                    );
                    //$('#Terminar Registo').prop('disabled', true);
                }

                //ID do tipo
                if (data == 1) //Existe
                {
                    $('#msg_num_mec').html(
                        '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">O número mecanográfio já existe! Verifique!</div>'
                    );
                    // $('#Terminar Registo').prop('disabled', true);
                }
                if (data == 4 ) //Okay
                     {
                        //$('#Terminar Registo').prop('disabled', false);
                        $('#msg_num_mec').html(
                           '<div id="alert-senha" class="alert alert-success alert-dismissible show" role="alert">O registro foi concluído com sucesso!</div>'
                        );
                        //$('#formfields').html('');
                     }
                if (data == 5) //Existe
                {
                    $('#msg_num_mec').html(
                        '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Todos os campos são de preenchimento obrigatório. Por favor, preencha os campos vazios.</div>'
                    );
                    // $('#Terminar Registo').prop('disabled', true);
                }

                //Validar nome tipo de utilizador
                if (data == 2) //Existe
                {
                    $('#msg_num_mec').html(
                        '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Já existe outro tipo de utilizador com o mesmo nome!</div>'
                    );

                    //$('#Terminar Registo').prop('disabled', true);
                }                
                if (data == 6) //Existe
                {
                    $('#msg_num_mec').html(
                        '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Os emails precisam ser terminados com o domínio <strong>@cm-espinho.pt</strong></div>'
                    );

                    //$('#Terminar Registo').prop('disabled', true);
                }
                
            }).fail(function(jqXHR, textStatus) {
                console.log("Request failed: " + textStatus);
            });
        });
    });
 </script>