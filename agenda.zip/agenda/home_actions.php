<?php
include_once('core/config.php');
$user_id = filter_var($_POST['user_id']);
$password = filter_var($_POST['password']);
$password_crypto = md5($password);
$a = 0;
//VERIFICA LOGIN/password
if ($stmt = $mysqli->prepare("SELECT user_id AS id FROM login WHERE user_id=?")) {
	$stmt->bind_param('s', $user_id);
	$stmt->execute();
	$result = $stmt->get_result();
	$stmt->close();

	$row = $result->num_rows;

	if ($row <= 0) {
		echo 0; // o user_id não existe
		die();
	} else if ($row >= 1) {
		$a = 1;
	}
} else {
	echo 'erro de conexão!';
}
//



// VERIFICA A PASSWORD
if ($a > 0) {
	if ($stmt = $mysqli->prepare("SELECT * FROM login WHERE password=?")) {
		$stmt->bind_param('s', $password_crypto);
		$stmt->execute();
		$result = $stmt->get_result();
		$row = $result->num_rows;
		if ($row <= 0) {
			echo 4;
		} else if ($row >= 1) {
			$row_utilizador = $result->fetch_object();
			$num_mec = $row_utilizador->user_id;
			$login_ses = $row_utilizador->nome_login;
			$hashsession_ses = $row_utilizador->hash_session;
			$session_ses = $row_utilizador->hash_session;
			$sessionname = md5(time() . microtime());

			//	$_SESSION['admin_id'] = $row['id'];
			$tempolimite = 1800; // tempo em segundos (30m)
			$_SESSION['registro'] = time();
			$_SESSION['limite'] = $tempolimite;
			$hash = md5(date('d/m/Y'));
			$_SESSION['user_id'] = $num_mec;
			$_SESSION['nome_login'] = $login_ses;
			$_SESSION['hash_session'] = $hashsession_ses;

			if ($session_ses == 0)
				echo 2;
			else {
				if ($_SESSION['hash_session'] == 1) {
					echo 3;
				} else {
					if ($_SESSION['hash_session'] == 0) {
						echo 5;
					}
				}
			}
		}

		$stmt->close();
	} else {
		echo 'erro de conexão!';
	}
}
