<?php
include_once('core/conexao.php');

// verifica_nivel();
// VERIFICA SE É VAZIO
if (empty($_POST['nome'])or  (empty($_POST['color'])))
    echo 2;
else {
    //VERIFICA NOME
    if (isset($_POST['nome'])) {
        $nome_tipo = filter_var($_POST['nome']);
        $color = filter_var($_POST['color']);

        if ($stmt = $con->prepare("SELECT nome_tipo, color FROM color WHERE nome_tipo=? or color=?")) {
            $stmt->bind_param('ss', $nome_tipo, $color);
            $stmt->execute();
            $result = $stmt->get_result();
            $numrow = $result->num_rows;
            if ($numrow <= 0) {
                echo 0;
                // INSERIR NA BASE DE DADOS
                $stmt = $con->prepare("INSERT INTO color (nome_tipo, color) VALUES (?, ?)");
                $stmt->bind_param('ss', $nome_tipo, $color);
                $stmt->execute();
                $stmt->close();
            } else if ($numrow >= 1) {
                $row = mysqli_fetch_array($result);
                $nome_tipo_i = $row['nome_tipo'];
                $color_i = $row['color'];
                if ($nome_tipo != $nome_tipo_i){
                    echo 1; 
                    die();
                }
                if ($color != $color_i){
                    echo 4; 
                    die();
                }
                else echo 3;
            }
        } else echo 'erro de conexão!';
    }
}