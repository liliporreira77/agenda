// Executar quando o documento HTML for completamente carregado
document.addEventListener('DOMContentLoaded', function () {

  // Receber o SELETOR calendar do atributo id
  var calendarEl = document.getElementById('calendar');

   // Receber o SELETOR da janela modal
      const inserirModal = new bootstrap.Modal(document.getElementById("inserirModal"));
 // Instanciar FullCalendar.Calendar e atribuir a variável calendar
  var calendar = new FullCalendar.Calendar(calendarEl, {

    // Incluir o bootstrap 5
    themeSystem: 'bootstrap5',

    // Criar o cabeçalho do calendário
    headerToolbar: {
      left: 'prev,next today',
      center: 'title',
      right: 'dayGridMonth,timeGridWeek,timeGridDay'
    },

    // Definir o idioma usado no calendário
    locale: 'pt',

    // Definir a data inicial
    //initialDate: '2023-01-12',
    //initialDate: '2023-10-12',

    // Permitir clicar nos nomes dos dias da semana 
    navLinks: true,

    // Permitir clicar e arrastar o mouse sobre um ou vários dias no calendário
    selectable: true,

    // Indicar visualmente a área que será selecionada antes que o usuário solte o botão do mouse para confirmar a seleção
    selectMirror: true,

    // Permitir arrastar e redimensionar os eventos diretamente no calendário.
    editable: true,

    // Número máximo de eventos em um determinado dia, se for true, o número de eventos será limitado à altura da célula do dia
    dayMaxEvents: true,

    events: 'listar_evento.php',

    // Identificar o clique do usuário sobre o evento
    eventClick: function (info) {
      console.log (info);
      // Receber o SELETOR da janela modal
      const visualizarModal = new bootstrap.Modal(document.getElementById("visualizarModal"));


      // Enviar para a janela modal os dados do evento
      document.getElementById("visualizar_id").innerText = info.event.id;
      document.getElementById("visualizar_titulo").innerText = info.event.title;
      document.getElementById("visualizar_inicio").innerText = info.event.start.toLocaleString();
      document.getElementById("visualizar_fim").innerText = info.event.end !== null ? info.event.end.toLocaleString() : info.event.start.toLocaleString();
      document.getElementById("visualizar_obs").innerText = info.event.extendedProps.obs;
      document.getElementById("visualizar_color_id").innerText = info.event.extendedProps.color_id;
      document.getElementById("visualizar_nome_tipo").innerText = info.event.extendedProps.nome_tipo;
      document.getElementById("visualizar_user_id").innerText = info.event.extendedProps.user_id;
      document.getElementById("visualizar_nome_login").innerText = info.event.extendedProps.nome_login;
      document.getElementById("visualizar_img").innerText = info.event.extendedProps.url;

      // Abrir a janela modal
      visualizarModal.show();
    },
    select: function (info) {

      // Chamar a função para converter a data selecionada para ISO8601 e enviar para o formulário
      document.getElementById("ins_start").value = converterData(info.start);
      document.getElementById("ins_end").value = converterData(info.start);

      // Abrir a janela modal inserir evento
      inserirModal.show();
    }
  });

   // rendarizar o calendário
  calendar.render();
 
 // Converter a data
  function converterData(data) {

    // Converter a string em um objeto Date
    const dataObj = new Date(data);

    // Extrair o ano da data
    const ano = dataObj.getFullYear();

    // Obter o mês, mês começa de 0, padStart adiciona zeros à esquerda para garantir que o mês tenha dígitos
    const mes = String(dataObj.getMonth() + 1).padStart(2, '0');

    // Obter o dia do mês, padStart adiciona zeros à esquerda para garantir que o dia tenha dois dígitos
    const dia = String(dataObj.getDate()).padStart(2, '0');

    // Obter a hora, padStart adiciona zeros à esquerda para garantir que a hora tenha dois dígitos
    const hora = String(dataObj.getHours()).padStart(2, '0');

    // Obter minuto, padStart adiciona zeros à esquerda para garantir que o minuto tenha dois dígitos
    const minuto = String(dataObj.getMinutes()).padStart(2, '0');

    // Retornar a data
    return `${ano}-${mes}-${dia} ${hora}:${minuto}`;
  }
  

   // Receber o SELETOR do formulário inserir evento
   const insertEvent = document.getElementById("insertEvent");

   // Receber o SELETOR da mensagem genérica
   const msg = document.getElementById("msg");

   // Receber o SELETOR da mensagem inserir evento
   const msgInsEvento = document.getElementById("msgInsEvento");

   // Receber o SELETOR do botão da janela modal inserir evento
   const btnInsEvento = document.getElementById("btnInsEvento");

   // Somente acessa o IF quando existir o SELETOR "insertEvent"
   if (insertEvent) {

       // Aguardar o usuario clicar no botao inserir
       insertEvent.addEventListener("submit", async (e) => {

           // Não permitir a atualização da pagina
           e.preventDefault();

           // Apresentar no botão o texto guardar
           btnInsEvento.value = "guardar...";

           // Receber os dados do formulário
           const dadosForm = new FormData(insertEvent);

           // Chamar o arquivo PHP responsável em salvar o evento
           const dados = await fetch("inserir_evento.php", {
               method: "POST",
               body: dadosForm
           });

           // Realizar a leitura dos dados retornados pelo PHP
           const resposta = await dados.json();

           // Acessa o IF quando não inserir com sucesso
           if (!resposta['status']) {
                document.getElementById("msgInsEvent").innerHTML=resposta['msg'];

               // Enviar a mensagem para o HTML
               msgInsEvento.innerHTML = `<div class="alert alert-danger" role="alert">${resposta['msg']}</div>`;

           }else{

               // Enviar a mensagem para o HTML
               msg.innerHTML = `<div class="alert alert-success" role="alert">${resposta['msg']}</div>`;

     

               // Limpar o formulário
               insertEvent.reset();

               // Criar o objeto com os dados do evento
               const novoEvento = {
                   id: resposta['id'],
                   title: resposta['title'],
                   start: resposta['start'],
                   end: resposta['end'],
                   obs: resposta['obs'],
                   user_id: resposta['user_id'],
                   color_id: resposta['color_id'],
                   image: resposta['url'],
               }

               // Adicionar o evento ao calendário
               calendar.addEvent(novoEvento);

               // Chamar a função para remover a mensagem após 3 segundo
               removerMsg();

               // Fechar a janela modal
               inserirModal.hide();
           }

           // Apresentar no botão o texto inserir
           btnInsEvento.value = "inserir";

       });
   }

   // Função para remover a mensagem após 3 segundo
   function removerMsg() {
       setTimeout(() => {
           document.getElementById('msg').innerHTML = "";
       }, 3000)
   }
});