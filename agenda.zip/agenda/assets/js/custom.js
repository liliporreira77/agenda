// Executar quando o documento HTML for completamente carregado
document.addEventListener('DOMContentLoaded', function () {
    // Receber o SELETOR da janela modal inserir
    const inserirModal = new bootstrap.Modal(document.getElementById("inserirModal"));

    // Receber o SELETOR da janela modal visualizar
    const visualizarModal = new bootstrap.Modal(document.getElementById("visualizarModal"));

    // Receber o SELETOR "msgViewEvento"
    const msgViewEvento = document.getElementById('msgViewEvento');

    function carregarEventos() {

        // Receber o SELETOR calendar do atributo id
        var calendarEl = document.getElementById('calendar');

        // Receber o id do cliente do campo Select
        var color_id = document.getElementById('color_id').value;

        // Instanciar FullCalendar.Calendar e atribuir a variável calendar
        var calendar = new FullCalendar.Calendar(calendarEl, {

            // Incluir o bootstrap 5
            themeSystem: 'bootstrap5',

            // Criar o cabeçalho do calendário
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay'
            },

            // Definir o idioma usado no calendário
            locale: 'pt-pt',

            // Definir a data inicial
            //initialDate: '2023-01-12',
            //initialDate: '2023-10-12',

            // Permitir clicar nos nomes dos dias da semana 
            navLinks: true,

            // Permitir clicar e arrastar o mouse sobre um ou vários dias no calendário
            selectable: true,

            // Indicar visualmente a área que será selecionada antes que o usuário solte o botão do mouse para confirmar a seleção
            selectMirror: true,

            // Permitir arrastar e redimensionar os eventos diretamente no calendário.
            editable: true,

            // Número máximo de eventos em um determinado dia, se for true, o número de eventos será limitado à altura da célula do dia
            dayMaxEvents: true,

            // Chamar o arquivo PHP para recuperar os eventos
            events: 'evento_listar.php?color_id=' + color_id,
            // Identificar o clique do usuário sobre o evento
            eventClick: function (info) {

                // Apresentar os detalhes do evento
                document.getElementById("visualizarEvento").style.display = "block";
                document.getElementById("visualizarModalLabel").style.display = "block";

                // Ocultar o formulário editar do evento
                document.getElementById("editarEvento").style.display = "none";
                document.getElementById("editarModalLabel").style.display = "none";

                // Enviar para a janela modal os dados do evento
                document.getElementById("visualizar_id").innerText = info.event.id;
                document.getElementById("visualizar_titulo").innerText = info.event.title;
                document.getElementById("visualizar_local").innerText = info.event.extendedProps.local;
                document.getElementById("visualizar_obs").innerText = info.event.extendedProps.obs;
                document.getElementById("visualizar_nome_tipo").innerText = info.event.extendedProps.nome_tipo;
                document.getElementById("visualizar_color_id").innerText = info.event.extendedProps.color_id;
                document.getElementById("visualizar_user_id").innerText = info.event.extendedProps.user_id;
                document.getElementById("visualizar_nome_login").innerText = info.event.extendedProps.nome_login;
                document.getElementById("visualizar_inicio").innerText = info.event.start.toLocaleString();
                document.getElementById("visualizar_fim").innerText = info.event.end !== null ? info.event.end.toLocaleString() : info.event.end.toLocaleString();
                document.getElementById("visualizar_img").innerText = info.event.extendedProps.image;
                img = document.getElementById("visualizar_img").innerHTML = info.event.extendedProps.image;
                if (!!img) {
                    // alert('Blocking Ads: Yes');
                    document.getElementById("visualizar_img").innerHTML = "<a  target=_blank href='" + info.event.extendedProps.image + "'>Ver Imagem</a>";
                } else {
                    // alert('Blocking Ads: No');
                    document.getElementById("visualizar_img").innerText = "Sem imagem";
                }
                // if (document.getElementById("visualizar_img").innerText !== null) {
                // } else {

                // }

                // Enviar os dados do evento para o formulário editar
                document.getElementById("edit_id").value = info.event.id;
                document.getElementById("edit_title").value = info.event.title;
                document.getElementById("edit_anexo").value = info.event.image!==null ?  info.event.image : document.getElementById("edit_anexo").value ="";
                document.getElementById("edit_obs").value = info.event.extendedProps.obs;
                document.getElementById("edit_local").value = info.event.extendedProps.local;
                document.getElementById("edit_start").value = converterData(info.event.start);
                document.getElementById("edit_end").value = info.event.end !== null ? converterData(info.event.end) : converterData(info.event.start);
                

                // Abrir a janela modal visualizar
                visualizarModal.show();
            },

            // Abrir a janela modal inserir quando clicar sobre o dia no calendário
            select: async function (info) {
                // Receber o SELETOR do campo usuário do formulário inserir
                var insUserId = document.getElementById('ins_user_id');

                // Chamar o arquivo PHP responsável em recuperar os usuários do banco de dados
                const dados = await fetch('utilizadores_listar.php');

                // Ler os dados
                const resposta = await dados.json();

                // Acessar o IF quando encontrar usuário no banco de dados
                if (resposta['status']) {

                    // Criar a opção selecione para o campo select usuários
                    var opcoes = '<option value="">Selecione</option>';

                    // Percorrer a lista de usuários
                    for (var i = 0; i < resposta.dados.length; i++) {

                        // Criar a lista de opções para o campo select usuários
                        opcoes += `<option value="${resposta.dados[i]['user_id']}">${resposta.dados[i]['nome_login']}</option>`;

                    }

                    // Enviar as opções para o campo select no HTML
                    insUserId.innerHTML = opcoes;

                } else {

                    // Enviar a opção vazia para o campo select no HTML
                    insUserId.innerHTML = `<option value=''>${resposta['msg']}</option>`;

                }

                // Receber o SELETOR do campo usuário do formulário inserir
                var insColorId = document.getElementById('ins_color_id');

                // Chamar o arquivo PHP responsável em recuperar os usuários do banco de dados
                const ascores = await fetch('cores_listar.php');

                // Ler os dados
                const respostaCor = await ascores.json();
                // console.log (respostaCor);
                // Acessar o IF quando encontrar usuário no banco de dados
                if (respostaCor['status']) {

                    // Criar a opção selecione para o campo select usuários
                    var opcoesCor = '<option value="">Selecione</option>';

                    // Percorrer a lista de usuários
                    for (var i = 0; i < respostaCor.ascores.length; i++) {

                        // Criar a lista de opções para o campo select usuários
                        opcoesCor += `<option value="${respostaCor.ascores[i]['color_id']}">${respostaCor.ascores[i]['nome_tipo']}</option>`;

                    }

                    // Enviar as opções para o campo select no HTML
                    insColorId.innerHTML = opcoesCor;

                } else {

                    // Enviar a opção vazia para o campo select no HTML
                    insColorId.innerHTML = `<option value=''>${respostaCor['msg']}</option>`;

                }


                // Chamar a função para converter a data selecionada para ISO8601 e enviar para o formulário
                document.getElementById("ins_start").value = converterData(info.start);
                document.getElementById("ins_end").value = converterData(info.end);

                // Abrir a janela modal inserir
                inserirModal.show();
            }
        });

        // Renderizar o calendário
        // calendar.render();

        // Retornar os dados do calendário
        return calendar;

    }


    // Chamar a função carregar eventos
    var calendar = carregarEventos();

    // Renderizar o calendário
    calendar.render();

    // Receber o seletor user_id do campo select
    var colorId = document.getElementById('color_id');

    // Aguardar o usuário selecionar valor no campo selecionar usuário
    colorId.addEventListener('change', function () {
        // console.log("Recuperar os eventos do usuário: " + userId.value);

        // Chamar a função carregar eventos
        calendar = carregarEventos();

        // Renderizar o calendário
        calendar.render();

    });


    // Converter a data
    function converterData(data) {

        // Converter a string em um objeto Date
        const dataObj = new Date(data);

        // Extrair o ano da data
        const ano = dataObj.getFullYear();

        // Obter o mês, mês começa de 0, padStart adiciona zeros à esquerda para garantir que o mês tenha dígitos
        const mes = String(dataObj.getMonth() + 1).padStart(2, '0');

        // Obter o dia do mês, padStart adiciona zeros à esquerda para garantir que o dia tenha dois dígitos
        const dia = String(dataObj.getDate()).padStart(2, '0');

        // Obter a hora, padStart adiciona zeros à esquerda para garantir que a hora tenha dois dígitos
        const hora = String(dataObj.getHours()).padStart(2, '0');

        // Obter minuto, padStart adiciona zeros à esquerda para garantir que o minuto tenha dois dígitos
        const minuto = String(dataObj.getMinutes()).padStart(2, '0');

        // Retornar a data
        return `${ano}-${mes}-${dia} ${hora}:${minuto}`;
    }

    // Receber o SELETOR do formulário inserir evento
    const insertEvent = document.getElementById("insertEvent");

    // Receber o SELETOR da mensagem genérica
    const msg = document.getElementById("msg");

    // Receber o SELETOR da mensagem inserir evento
    const msginsEvento = document.getElementById("msginsEvento");

    // Receber o SELETOR do botão da janela modal inserir evento
    const btnInsEvento = document.getElementById("btnInsEvento");

    // Somente acessa o IF quando existir o SELETOR "insertEvent"
    if (insertEvent) {

        // Aguardar o usuario clicar no botao inserir
        insertEvent.addEventListener("submit", async (e) => {

            // Não permitir a atualização da pagina
            e.preventDefault();

            // Apresentar no botão o texto A gravar
            btnInsEvento.value = "A gravar...";

            // Receber os dados do formulário
            const dadosForm = new FormData(insertEvent);

            // Chamar o arquivo PHP responsável em salvar o evento
            const dados = await fetch("evento_inserir.php", {
                method: "POST",
                body: dadosForm
            });

            // Realizar a leitura dos dados retornados pelo PHP
            const resposta = await dados.json();

            // Acessa o IF quando não inserir com sucesso
            if (!resposta['status']) {

                // Enviar a mensagem para o HTML
                msginsEvento.innerHTML = `<div class="alert alert-danger" role="alert">${resposta['msg']}</div>`;

            } else {

                // Enviar a mensagem para o HTML
                msg.innerHTML = `<div class="alert alert-success" role="alert">${resposta['msg']}</div>`;

                // Enviar a mensagem para o HTML
                msginsEvento.innerHTML = "";

                // Limpar o formulário
                insertEvent.reset();

                // Receber o id do usuário do campo Select
                var color_id = document.getElementById('color_id').value;
                // Verificar se existe a pesquisa pelo usuário, se o cadastro for para o mesmo usuário pesquisado, acrescenta no FullCalendar
                if (color_id == "" || resposta['color_id'] == color_id) {

                    // Criar o objeto com os dados do evento
                    const novoEvento = {
                        id: resposta['id'],
                        title: resposta['title'],
                        start: resposta['start'],
                        end: resposta['end'],
                        obs: resposta['obs'],
                        local: resposta['local'],
                        user_id: resposta['user_id'],
                        nome_login: resposta['nome_login'],
                        color_id: resposta['color_id'],
                        nome_tipo: resposta['nome_tipo'],
                        color: resposta['color'],
                        image: resposta['image'],
                    }

                    // Adicionar o evento ao calendário
                    calendar.addEvent(novoEvento);
                }
                // Chamar a função para remover a mensagem após 3 segundo
                removerMsg();

                // Fechar a janela modal
                inserirModal.hide();
            }

            // Apresentar no botão o texto inserir
            btnInsEvento.value = "inserir";

        });
    }

    // Função para remover a mensagem após 3 segundo
    function removerMsg() {
        setTimeout(() => {
            document.getElementById('msg').innerHTML = "";
        }, 3000)
    }

    // Receber o SELETOR ocultar detalhes do evento e apresentar o formulário editar evento
    const btnViewEditEvento = document.getElementById("btnViewEditEvento");

    // Somente acessa o IF quando existir o SELETOR "btnViewEditEvento"
    if (btnViewEditEvento) {

        // Aguardar o usuario clicar no botao editar
        btnViewEditEvento.addEventListener("click", async () => {

            // Ocultar os detalhes do evento
            document.getElementById("visualizarEvento").style.display = "none";
            document.getElementById("visualizarModalLabel").style.display = "none";

            // Apresentar o formulário editar do evento
            document.getElementById("editarEvento").style.display = "block";
            document.getElementById("editarModalLabel").style.display = "block";

            // Receber o SELETOR do campo usuário do formulário inserir
            var colorId = document.getElementById('visualizar_color_id').innerText;
            // Receber o SELETOR do campo usuário do formulário editar
            var editColorId = document.getElementById('edit_color_id');
            // Chamar o arquivo PHP responsável em recuperar os usuários do banco de dados
            const ascores = await fetch('cores_listar.php');

            // Ler os dados
            const respostaCor = await ascores.json();
            // console.log (respostaCor);
            // Acessar o IF quando encontrar usuário no banco de dados
            if (respostaCor['status']) {

                // Criar a opção selecione para o campo select usuários
                var opcoesCor = '<option value="">Selecione</option>';

                // Percorrer a lista de usuários
                for (var i = 0; i < respostaCor.ascores.length; i++) {
                    opcoesCor += `<option value="${respostaCor.ascores[i]['color_id']}" ${colorId == respostaCor.ascores[i]['color_id'] ? 'selected' : ""}>${respostaCor.ascores[i]['nome_tipo']}</option>`;

                }

                // Enviar as opções para o campo select no HTML
                editColorId.innerHTML = opcoesCor;

            } else {

                // Enviar a opção vazia para o campo select no HTML
                editColorId.innerHTML = `<option value=''>${respostaCor['msg']}</option>`;

            }

            // Receber o id do usuário responsável pelo evento
            var userId = document.getElementById('visualizar_user_id').innerText;

            // Receber o SELETOR do campo usuário do formulário editar
            var editUserId = document.getElementById('edit_user_id');

            // Chamar o arquivo PHP responsável em recuperar os usuários do banco de dados
            const dados = await fetch('utilizadores_listar.php');

            // Ler os dados
            const resposta = await dados.json();
            //console.log(resposta);

            // Acessar o IF quando encontrar usuário no banco de dados
            if (resposta['status']) {

                // Criar a opção selecione para o campo select usuários
                var opcoes = '<option value="">Selecione</option>';

                // Percorrer a lista de usuários
                for (var i = 0; i < resposta.dados.length; i++) {

                    // Criar a lista de opções para o campo select usuários
                    opcoes += `<option value="${resposta.dados[i]['user_id']}" ${userId == resposta.dados[i]['user_id'] ? 'selected' : ""}>${resposta.dados[i]['nome_login']}</option>`;

                }

                // Enviar as opções para o campo select no HTML
                editUserId.innerHTML = opcoes;

            } else {

                // Enviar a opção vazia para o campo select no HTML
                editUserId.innerHTML = `<option value=''>${resposta['msg']}</option>`;

            }
        });
    }

    // Receber o SELETOR ocultar formulário editar evento e apresentar o detalhes do evento
    const btnViewEvento = document.getElementById("btnViewEvento");

    // Somente acessa o IF quando existir o SELETOR "btnViewEvento"
    if (btnViewEvento) {

        // Aguardar o usuario clicar no botao editar
        btnViewEvento.addEventListener("click", () => {

            // Apresentar os detalhes do evento
            document.getElementById("visualizarEvento").style.display = "block";
            document.getElementById("visualizarModalLabel").style.display = "block";

            // Ocultar o formulário editar do evento
            document.getElementById("editarEvento").style.display = "none";
            document.getElementById("editarModalLabel").style.display = "none";
        });
    }

    // Receber o SELETOR do formulário editar evento
    const formEditEvento = document.getElementById("formEditEvento");

    // Receber o SELETOR da mensagem editar evento 
    const msgEditEvento = document.getElementById("msgEditEvento");

    // Receber o SELETOR do botão editar evento
    const btnEditEvento = document.getElementById("btnEditEvento");

    // Somente acessa o IF quando existir o SELETOR "formEditEvento"
    if (formEditEvento) {

        // Aguardar o usuario clicar no botao editar
        formEditEvento.addEventListener("submit", async (e) => {

            // Não permitir a atualização da pagina
            e.preventDefault();

            // Apresentar no botão o texto A gravar
            btnEditEvento.value = "A gravar...";

            // Receber os dados do formulário
            const dadosForm = new FormData(formEditEvento);

            // Chamar o arquivo PHP responsável em editar o evento
            const dados = await fetch("evento_editar.php", {
                method: "POST",
                body: dadosForm
            });

            // Realizar a leitura dos dados retornados pelo PHP
            const resposta = await dados.json();

            // Acessa o IF quando não editar com sucesso
            if (!resposta['status']) {

                // Enviar a mensagem para o HTML
                msgEditEvento.innerHTML = `<div class="alert alert-danger" role="alert">${resposta['msg']}</div>`;
            } else {

                // Enviar a mensagem para o HTML
                msg.innerHTML = `<div class="alert alert-success" role="alert">${resposta['msg']}</div>`;

                // Enviar a mensagem para o HTML
                msgEditEvento.innerHTML = "";

                // Limpar o formulário
                formEditEvento.reset();

                // Recuperar o evento no FullCalendar pelo id 
                const eventoExiste = calendar.getEventById(resposta['id']);
                // Receber o id do usuário do campo Select
                var color_id = document.getElementById('color_id').value;

                // Verificar se existe a pesquisa pelo usuário, se o editar for para o mesmo usuário pesquisado, manten no FullCalendar
                if (color_id == "" || resposta['color_id'] == color_id) {

                    // Verificar se encontrou o evento no FullCalendar pelo id
                    if (eventoExiste) {
                        // console.log(eventoExiste);
                        // Atualizar os atributos do evento com os novos valores do banco de dados
                        eventoExiste.setProp('title', resposta['title']);
                        eventoExiste.setStart(resposta['start']);
                        eventoExiste.setEnd(resposta['end']);
                        eventoExiste.setExtendedProp('obs', resposta['obs']);
                        eventoExiste.setExtendedProp('local', resposta['local']);
                        eventoExiste.setExtendedProp('user_id', resposta['user_id']);
                        eventoExiste.setExtendedProp('nome_login', resposta['nome_login']);
                        eventoExiste.setExtendedProp('color_id', resposta['color_id']);
                        eventoExiste.setProp('color', resposta['color']);
                        eventoExiste.setExtendedProp('nome_tipo', resposta['nome_tipo']);
                        eventoExiste.setExtendedProp('image', resposta['image']);
                    }

                } else {

                    // Verificar se encontrou o evento no FullCalendar pelo id
                    if (eventoExiste) {

                        // Remover o evento do calendário
                        eventoExiste.remove();
                    }
                }

                // Chamar a função para remover a mensagem após 3 segundo
                removerMsg();

                // Fechar a janela modal
                visualizarModal.hide();
            }

            // Apresentar no botão o texto salvar
            btnEditEvento.value = "Gravar";
        });
    }
    // Receber o SELETOR apagar evento
    const btnApagarEvento = document.getElementById("btnApagarEvento");

    // Somente acessa o IF quando existir o SELETOR "formEditEvento"
    if (btnApagarEvento) {

        // Aguardar o usuario clicar no botao apagar
        btnApagarEvento.addEventListener("click", async () => {

            // Exibir uma caixa de diálogo de confirmação
            const confirmacao = window.confirm("Tem certeza de que deseja apagar este evento?");

            // Verificar se o usuário confirmou
            if (confirmacao) {

                // Receber o id do evento
                var idEvento = document.getElementById("visualizar_id").textContent;

                // Chamar o arquivo PHP responsável apagar o evento
                const dados = await fetch("evento_apagar.php?id=" + idEvento);

                // Realizar a leitura dos dados retornados pelo PHP
                const resposta = await dados.json();

                // Acessa o IF quando não inserir com sucesso
                if (!resposta['status']) {

                    // Enviar a mensagem para o HTML
                    msgViewEvento.innerHTML = `<div class="alert alert-danger" role="alert">${resposta['msg']}</div>`;
                } else {   

                    // Enviar a mensagem para o HTML
                    msg.innerHTML = `<div class="alert alert-success" role="alert">${resposta['msg']}</div>`;

                    // Enviar a mensagem para o HTML
                    msgViewEvento.innerHTML = "";

                    // Recuperar o evento no FullCalendar
                    const eventoExisteRemover = calendar.getEventById(idEvento);

                    // Verificar se encontrou o evento no FullCalendar
                    if (eventoExisteRemover) {

                        // Remover o evento do calendário
                        eventoExisteRemover.remove();
                    }

                    // Chamar a função para remover a mensagem após 3 segundo
                    removerMsg();

                    // Fechar a janela modal
                    visualizarModal.hide();

                }
            }
        });

    }
});


// Receber o seletor do campo listar os usuários
const color = document.getElementById("color_id");

// Verificar se existe o seletor color_id no HTML
if (color) {

    // Chamar a função
    listarCores();
}

// Função para recuperar os usuários
async function listarCores() {

    // Chamar o arquivo PHP para recuperar os usuários
    const ascores = await fetch('cores_listar.php');

    // Ler os ascores retornado do PHP
    const resposta = await ascores.json();
    // console.log(resposta);

    // Verificar se status é TRUE e acessa o IF, senão acessa o ELSE e retorna a mensagem de erro 
    if (resposta['status']) {

        // Criar a variável com as opções para o campo SELECT
        var opcoes = `<option value="">Selecione tipo de evento</option>`;

        // Percorrer o array de usuários
        for (var i = 0; i < resposta.ascores.length; i++) {

            // Atribuir o usuário como opção para o campo SELECT
            opcoes += `<option value="${resposta.ascores[i]['color_id']}">${resposta.ascores[i]['nome_tipo']}</option>`;
        }

        // Enviar para o HTML as opções para o campo SELECT
        color.innerHTML = opcoes;
    } else {

        // Enviar para o HTML as opções para o campo SELECT
        color.innerHTML = `<option value="">${resposta['msg']}</option>`;
    }
}
