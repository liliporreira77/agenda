<?php
// includes do phpmail.
include_once 'core/config.php';
include_once 'core/conexao.php';

//Aqui é a página onde você vai criar o script que vai excluir, editar ou enviar o email

if (isset($_POST['id'])) {
    $id = (int) filter_var($_POST['id'], FILTER_SANITIZE_NUMBER_INT);
} else {
    $id = (int) isset($_GET['userid']) ? $_GET['userid'] : '';
}

$action_type = filter_var($_POST['acttp'], FILTER_SANITIZE_NUMBER_INT);

if ($action_type == 1) //aqui você faz o script que faz a função de reenviar o email para o usuário
{
    $result = mysqli_query($con, "SELECT user_id, nome_login, email FROM login WHERE user_id=$id");
    $row = mysqli_fetch_row($result);
    $_id1 = $row[0]; //echo $_id
    $nome1 = $row[1];
    $email1 = $row[2];

    //Gera uma senha aleatória e única de aceuesso primário
    $senha_hash_md5 = md5($_id1);
    $hash_session = 0;
    $update_user = mysqli_query($mysqli, "UPDATE login SET password='" . $senha_hash_md5 . "', hash_session='" . $hash_session . "' WHERE user_id=" . $id . "");
    echo "A nova password já foi enviada predefinida, novamente.";
}
if ($action_type == 2) //apaga o utilizador
{
    $sql_u = mysqli_query($mysqli, "DELETE FROM events WHERE user_id=" . $id . "");
    $sql_utilizador = mysqli_query($mysqli, "DELETE FROM login WHERE user_id=" . $id . "");
    $mmun = (object) array("userid" => $id, "retorno" => 0, "nome" => "search:");
    echo json_encode($mmun);
}
if ($action_type == 3) //aqui você faz o script que te direciona pra página de edição de dados
{
    $mmun = (object) array("userid" => $id, "retorno" => 1, "nome" => "search:");
    echo json_encode($mmun);
}