<?php
include_once './core/config.php';
include_once './core/conexao.php';
if ((empty($_POST['nome_nivel'])) or (empty($_POST['descricao'])))
    echo 1;
else {
    $nivel_id = (int) filter_var($_POST['nivel_id']);
    $nome_nivel = filter_var($_POST['nome_nivel']);
    $descricao = filter_var($_POST['descricao']);
    $stmt = $con->prepare("SELECT nivel_id, nome_nivel, descricao FROM nivel WHERE nivel_id<>? and (nome_nivel=? or descricao=?)");
    $stmt->bind_param('sss', $nivel_id, $nome_nivel, $descricao);
    $stmt->execute();
    $result = $stmt->get_result();
    $numrow = $result->num_rows;

    if ($numrow >= 1) {
        $row = mysqli_fetch_array($result);
        $nivel_id_i = $row['nivel_id'];
        $nome_nivel_i = $row['nome_nivel'];
        $descricao_i = $row['descricao'];
        if ($nome_nivel == $nome_nivel_i) {
            echo 3;
            die();
        }
    }
    // UPDATE NA BASE DE DADOS
    $sql = "UPDATE nivel SET nome_nivel='$nome_nivel', descricao='$descricao' WHERE nivel_id=$nivel_id";
    if (mysqli_query($con, $sql)) {
        echo 0;
        die();
    }
}
