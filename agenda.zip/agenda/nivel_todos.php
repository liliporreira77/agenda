<?php 
// verifica_nivel();
require('core/conexao.php');
?>
<!-- MDBootstrap Datatables  -->
<div class='container-fluid'>
<div class="row" style="margin-left: 3em !important;">
        <div class='col-12' style='padding-top:25px;'>
            <table id='example' class='table table-striped table-bordered'>
                <thead>
                    <!--O numero de colunas-->
                    <tr>
                        <th class='tableth' style="text-align: center;">ID</th>
                        <th class='tableth' style="text-align: center;">Nome do nivel</th>
                        <th class='tableth' style="text-align: center;">Descrição</th>
                        <th class='tableth' style="text-align: center;">ações</th>
                    </tr>
                </thead>
                <tbody> <?php
                        echo '<tr>';
                        $result = 'SELECT * FROM nivel';
                        $resultado = mysqli_query($con, $result);
                        while ($row = mysqli_fetch_assoc($resultado)) {
                            echo '<td align=center>' . $row['nivel_id'] . '</td> ';
                            echo '<td align=center>' . $row['nome_nivel'] . '</td> ';
                            echo '<td align=center>' . $row['descricao'] . '</td> ';
                        ?> <td style='padding: 4px; width:80px; text-align: center;'>
                            <button type='button' onclick="acaoDoAdministrador('<?php echo $row['nivel_id']; ?>','delete');" class='btn btn-danger btn-sm btn-admin-actions' title='Apagar'><span class='fas fa-times fa-sm'></span> </button>
                            <button type='button' onclick="acaoDoAdministrador('<?php echo $row['nivel_id']; ?>','edit');" class='btn btn-success btn-sm btn-admin-actions' title='Editar'><span class='fas fa-edit  fa-sm'></span> </button>
                        </td> <?php
                                echo '</tr>';
                            }
                                ?>
            </table>
    </div>
</div>

<script src="assets/js/datatables.min.js"></script>

<script type="text/javascript">
let table = new DataTable('#example', {
    "ordering": false,
    language: {
      sSearch: '',
        searchPlaceholder: 'Procurar',
        lengthMenu: 'Apresentar _MENU_ linhas por página',
        zeroRecords: 'Não há registos',
        info: 'Monstrandro a página _PAGE_ de _PAGES_',
        infoEmpty: 'Não há registos',
        infoFiltered: '(filtrando de _MAX_ registos)',
    }
});
    function acaoDoAdministrador(id, acao) {
        if (acao == 'delete') {
            let text = 'Pertende apagar este nível de utilizadores da base de dados?';
            if (confirm(text) == true) {
                var action_type = 1;
                // se for do tipo 'deletar usuário do sistema'
                txt = 'You pressed OK!';
                setTimeout(function() {
                    window.location.reload();
                }, 2500);
            } else {
                text = 'Cancelar!';
            }
        } else if (acao == 'edit') {
            var action_type = 2;
            // se for do tipo 'editar dados do usuário'
        }
        //Faz a requisição para o script em 'registo_todos_actions.php'
        $.ajax({
            url: 'nivel_todos_actions.php',
            type: 'POST',
            data: {
                usertarget: id,
                acttp: action_type
            },
            dataType: 'json',
            success: function(data) {
                //alert( data );
                //console.log ( data );
                if (data.retorno == 1) {
                    window.location.href = '?pg=8&nivel_id=' + data.nivel_id;
                } else if (data.retorno == 0) {
                    setTimeout(function() {
                        window.location.reload();
                    }, 2500);
                }
            }
        });
    }
</script>
</div>