<?php

require('core/config.php');
require('core/conexao.php');
$nivel_id = filter_var($_POST['usertarget'], FILTER_SANITIZE_NUMBER_INT);
$action_type = filter_var($_POST['acttp'], FILTER_SANITIZE_NUMBER_INT);

if ($action_type == 1) {
    $sql_utilizador = mysqli_query($mysqli, "DELETE FROM nivel WHERE nivel_id=" . $nivel_id . "");
    $nivel_id = (object) array("nivel_id" => $nivel_id, "retorno" => 0, "nome" => "search:");
    echo json_encode($nivel_id);
}

if ($action_type == 2) {
    $nivel_id = (object) array("nivel_id" => $nivel_id, "retorno" => 1, "nome" => "search:");
    echo json_encode($nivel_id);
}
