<?php
if (!isset($_SESSION)) {
    session_start();
}
include_once './core/config.php';
include_once './core/conexao.php';
function x($var)
{
    echo '<pre>';
    echo print_r($var, 1);
    echo '</pre>';
}

function xd($var)
{
    echo '<pre>';
    echo var_dump($var);
    echo '</pre>';
}

// //Verifica qual página está sendo requisitada
if (isset($_GET['pg'])) {
    $pg = filter_var($_GET['pg'], FILTER_SANITIZE_NUMBER_INT);
    if ($pg == 1) {
        $titulo_pg = 'LOGIN';
        $pagina = 'logout'; //arquivo PHP da pasta "template"
    } else if ($pg == 2) {
        $titulo_pg = 'Calendário'; //<<<< Painel Pós-Login
        $pagina = 'calendario'; //arquivo PHP da pasta "template
    } else if ($pg == 3) {
        $titulo_pg = 'Inserir utilizador';
        $pagina = 'login_novo';
    } else if ($pg == 4) {
        $titulo_pg = 'Alterar utilizador';
        $pagina = 'login_alterar';       
    } else if ($pg == 5) {
        $titulo_pg = 'Listar todos utilizadores';
        $pagina = 'login_todos';
    } else if ($pg == 6) {
        $titulo_pg = 'Reenviar nova password';
        $pagina = 'login_email';
    } else if ($pg == 7) {
        $titulo_pg = 'Inserir tipo de evento';
        $pagina = 'tipoevento_inserir';
    } else if ($pg == 8) {
        $titulo_pg = 'Alterar tipo de evento';
        $pagina = 'tipoevento_alterar';
    } else if ($pg == 9) {
        $titulo_pg = 'Listar todos';
        $pagina = 'tipoevento_todos';
    } 
    //Página de Testes
    else if ($pg == 123456) {
        $titulo_pg = 'Página de Testes';
        $pagina = '_teste'; //arquivo PHP da pasta "template"
    }

    //Página Desconhecida (Broken Link)
    else {
        $titulo_pg = 'Erro 404 - Página Desconhecida';
        $pagina = '404'; //arquivo PHP da pasta "template"
    }
} else {
    $titulo_pg = 'Início';$pg="";
    $pagina = 'home'; //arquivo PHP da pasta "template"
    unset($_SESSION['registro']);
    unset($_SESSION['limite']);
    unset($_SESSION['hash']);
    unset($_SESSION['num']);
    unset($_SESSION['nome']);
    session_destroy();
}?>

<!DOCTYPE HTML>



<html lang="pt-pt">

<head>
    <title> Agenda de Eventos </title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>    

    <link href='https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css' rel='stylesheet'>

        <!-- css -->
    <link rel="stylesheet" href="assets/css/datatables.min.css" />
    <link rel="stylesheet" href="assets/css/main.css" />
</head>

<?php if ($pagina != "home") { ?>
<body class="is-preload">
    <!-- Wrapper -->
    <div id="wrapper">

        <!-- Main -->
        <div id="main">
            <div class="inner">

                <!-- Header -->
                <header id="header">
                    <div class="logo">Agenda de Eventos </div>
                    <div class="pesquisa" >
                    <form class="ms-2" >
                        <?php if ($pg == 2) {?>
                                <select name="color_id" id="color_id" class="form-select">
                                    <option value="">Tipo de evento</option>
                                </select>
                            <?php } ?>
                </header>
                </form>


                <div class="container">
                    <?php include  $pagina . '.php'; ?>

                </div>

            </div>
        </div>

        <!-- Sidebar -->
        <div id="sidebar">
            <div class="inner">

                <!-- Search -->
                <section id="search" class="alt">
                    <div class="logotipo">
                        <a href="?pg=1"> <img src="images/logotipo.png"></a>
                    </div>
                </section>

                <!-- Menu -->
                <nav id="menu">
                    <header class="major">
                        <h2>Menu</h2>
                    </header>
                    <ul>
                        
                        <li>
                            <span class="opener">LOGIN</span>
                            <ul>
                                <li><a href="?pg=3">Inserir</a></li>
                                <li><a href="?pg=5">Visualizar</a></li>
                            </ul>
                        </li>
                        <li>
                            <span class="opener">TIPO DE EVENTO</span>
                            <ul>
                                <li><a href="?pg=7">Inserir</a></li>
                                <li><a href="?pg=9">Visualizar</a></li>
                            </ul>
                        </li>
                    </ul>
                    <div class="labelbotton">
                    <a href="?pg=2" class="button">Calendário</a>
                    </div>
                </nav>

                <!-- Footer -->
                <footer id="footer">
                    <p class="copyright"> <?php include 'footer.php'; ?></p>
                </footer>

            </div>
        </div>

    </div>
<?php } else include  $pagina . '.php'; ?>

<?php if ($pg == 2) {?>
    
    <!-- Scripts boostrap -->    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
    <script src='assets/js/index.global.min.js'></script>
    <script src="assets/js/bootstrap5/index.global.min.js"></script>
    <script src='assets/js/core/locales-all.global.min.js'></script>
    <script src='assets/js/custom.js'></script>
    
    <?php } ?>
    
    <!-- <script src="assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
    <script src="assets/js/jquery-ui.min.js" type="text/javascript"></script>
    <script src="assets/js/scripts.js"></script> -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js"
        integrity="sha256-KzZiKy0DWYsnwMF+X1DvQngQ2/FxF7MF3Ff72XcpuPs=" crossorigin="anonymous"></script>

    
    
        <script src="assets/js/bootstrap.bundle.min.js.map"></script>
    <!-- Scripts -->

    
    <script src="assets/js/browser.min.js"></script>
    <script src="assets/js/breakpoints.min.js"></script>
    <script src="assets/js/util.js"></script>
    <script src="assets/js/main.js"></script>
    <!-- Scripts fulcadenlary -->

</body>

</html>