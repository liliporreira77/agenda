<?php

// Incluir o arquivo com a conexão com banco de dados
include_once './conexao.php';
// Receber os dados enviado pelo JavaScript
$dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

// Recuperar os dados do usuário no banco de dados
// Receber o id do cliente
$client_id = filter_input(INPUT_GET, 'client_id', FILTER_SANITIZE_NUMBER_INT);
var_dump($client_id); die();
$query_user = "SELECT user_id,nome_login, email FROM login WHERE user_id =:user_id LIMIT 1";

// Prepara a QUERY
$result_user = $conn->prepare($query_user);

// Substituir o link pelo valor
$result_user->bindParam(':user_id', $dados['ins_utilizador']);

// Executar a QUERY
$result_user->execute();

// QUERY para recuperar os eventos
$query_events = "SELECT events.id, events.title, events.obs, events.start, events.end, events.image, color.nome_tipo, color.color_id, login.user_id, login.nome_login FROM login INNER JOIN (color INNER JOIN events ON color.color_id = events.color_id) ON (login.user_id = events.user_id) AND (login.user_id = events.user_id)";

// Prepara a QUERY
$result_events = $conn->prepare($query_events);

// Executar a QUERY
$result_events->execute();

// Criar o array que recebe os eventos
$eventos = [];

// Percorrer a lista de registros retornado do banco de dados
while($row_events = $result_events->fetch(PDO::FETCH_ASSOC)){

    // Extrair o array
    extract($row_events);

    $eventos[] = [
        'id' => $id,
        'title' => $title,
        'color_id' => $color_id,
        'nome_tipo' => $nome_tipo,
        'start' => $start,
        'end' => $end,
        'obs' => $obs,
        'image' => $image,
        'user_id' => $user_id,
        'nome_login' => $nome_login,
    ];
}

echo json_encode($eventos);