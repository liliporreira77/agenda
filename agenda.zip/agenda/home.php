<?php
if (!isset($_SESSION)) {
    session_destroy();
}
?>
<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <title>LOGIN</title>
    <meta charset="utf-8">
    <meta name="author" content="Liliana">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="data:;base64,iVBORw0KGgo=">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.2/css/bootstrap-select.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/login.css">
</head>

<body>
    <div id="login">
        <div class="container">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                        <div class="logo_bl">
                            <img src="images/logotipo.png"></a>
                        </div>
                        <div class="dv">Divisão de Promoção e Eventos</div>
                        <form id="loginform" method="POST">
                            <h3 class="TLogin">Login</h3>
                            <div id="msg_num_mec"></div>
                            <div class="form-group">
                                <label for="user_id" class="text-info">Número Mecanográfico</label>
                                <input type="text" name="user_id" id="user_id" class="form-control">
                            </div><br>
                            <div class="form-group">
                                <label for="password" class="text-info">Password:</label>
                                <input type="password" id="password" name="password" class="form-control"
                                    placeholder="Password" required>
                            </div>

                            <div id="labelbotton">
                                    <input type="submit" name="submit"id="bt_login" value="Entrar">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
    $(document).ready(function() {
        $('#loginform').submit(function(e) {
            e.preventDefault();
            $.ajax({
                type: "POST",
                url: 'home_actions.php',
                data: $(this).serialize(),
                success: function(data) {
                    console.log(data);

                    if (data == 0) {
                        $('#msg_num_mec').html(
                            '<div id="alert-password" class="alert alert-danger alert-dismissible show" role="alert">O e-mail não existe!</div>'
                        );
                    }

                    //Valida password
                    if (data == 2) //password Correta e a primeira vez
                    {
                        window.location = "index.php?pg=4"
                    } 
                    if (data == 3) //password Correta
                    {
                        window.location = "index.php?pg=2"
                    }  if (data == 5) //password Correta
                    {
                        window.location = "index.php?pg=2"
                    } if (data == 6) //password Correta HASH=1
                    {
                        window.location = "index.php?pg=2"
                    }
                    //Valida password
                    if (data == 4) //password Incorreta
                    {
                        $('#msg_num_mec').html(
                            '<div id="alert-password" class="alert alert-danger alert-dismissible show" role="alert">A password está errada. Digite novamente.</div>'
                        );
                    }

                }
            });
        });
    });
    </script>
    <script src="assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
    <script src="assets/js/jquery-ui.min.js" type="text/javascript"></script>
    <script src="assets/js/scripts.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js"
        integrity="sha256-KzZiKy0DWYsnwMF+X1DvQngQ2/FxF7MF3Ff72XcpuPs=" crossorigin="anonymous"></script>

</body>

</html>