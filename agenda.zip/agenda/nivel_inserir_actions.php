<?php
include_once './core/config.php';
include_once './core/conexao.php';
// verifica_nivel();
// VERIFICA SE É VAZIO
if ((empty($_POST['nome'])) or (empty($_POST['descricao'])))
    echo 3;
else {
    //VERIFICA NOME
    if (isset($_POST['nome'])) {
        $nome_nivel = filter_var($_POST['nome']);
        $descricao = filter_var($_POST['descricao']);
        if ($stmt = $con->prepare("SELECT nome_nivel FROM nivel WHERE nome_nivel=?")) {
            $stmt->bind_param('s', $nome_nivel);
            $stmt->execute();
            $result = $stmt->get_result();
            $numrow = $result->num_rows;
            if ($numrow <= 0) {
                echo 0;
                // INSERIR NA BASE DE DADOS
                $stmt = $con->prepare("INSERT INTO nivel (nome_nivel, descricao) VALUES ( ?, ?)");
                $stmt->bind_param('ss', $nome_nivel, $descricao);
                $stmt->execute();
                $stmt->close();
            } else if ($numrow >= 1) {
                $row = mysqli_fetch_array($result);
                $nome_nivel_i = $row['nome_nivel'];
                if ($nome_nivel != $nome_nivel_i)
                    echo 1;
                else echo 2;
            }
        } else echo 'erro de conexão!';
    }
}
