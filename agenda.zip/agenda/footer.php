Copyright &copy;
<?php echo date("Y"); ?> <br>
Todos os Direitos Reservados<br>
Câmara Municipal de Espinho