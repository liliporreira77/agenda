<?php 
verifica_session();

?>
<div class="container content__boxed" style="text-align: center;">
    <div id="divCenter">
      <div class="form-block">
        <form method="post" action="" id="novoregisto" autocomplete="off">
          <?php
            $userid = isset($_GET['userid']) ? $_GET['userid'] : '';
            // echo $userid;
            if ($userid != '') {
              $userid = $userid; ?>
                    <h1>Editar utilizador<br> </h1>
                    <?php
            } else {
              $userid = $_SESSION['user_id']; ?>
                    <h1>Complete o seu registo<br> </h1>
          <?php } ?>
          <div id="msg_num_mec"> </div>
          <?php
            // VERIFICA  O ID_servico

            $result = mysqli_query($con, "SELECT login.user_id, login.nome_login, login.email, login.hash_session FROM login WHERE user_id = '$userid'");
            $row = mysqli_fetch_row($result);
            $user_id = $row[0]; //echo $user_id
            $nome_login = $row[1];
            $email = $row[2];
            $hash_session = $row[3];
          ?>
          <div><input type="hidden" id="num" name="num" class="form-input form-pequenos" style="width:250px;" value="<?php echo $user_id ?>"></div>
          <label for="nome" class="form-itens">Nome: </label>
          <input type="text" id="nome" name="nome" Class="form-block" value="<?php echo $nome_login ?>">
          <label for="email" class="form-itens">E-mail: </label>
          <input type="email" id="email" name="email" Class="form-block" value="<?php echo $email ?>">

          <?php if ($userid == $_SESSION['user_id']) { ?>
            <label for="password" class="form-itens">Password:</label>
            <div class="wrapper">
                <input type="password" id="password" autocomplete="new-password" name="password"
                    class="form-itens form-pequenos">
                </div>
            <label for="password_confirma" class="form-itens">Confirmar password:</label>
            <div class="wrapper">
                <input type="password" id="password_confirma" name="password_confirma"
                    class="form-itens form-pequenos">

            </div>
        <?php }
        if ($userid != "") { ?>
        <div class="labelbotton">
            <input class="button-default form-submit" id="submit_new_user" type="button" value="Concluir">
        </div>
        <?php } else {
          $userid = $_SESSION['user_id']; ?>
        <div class="labelbotton">
            <input class="button-default form-submit" id="submit_new_user" type="button" value="Gravar">
        </div>
        <?php } ?>
        </form> 
      </div>
  </div>
</div>


<script type="text/javascript">
    $(document).ready(function() {
        var user_id = '<?php echo  $user_id; ?>';

        //validação
        $('#submit_new_user').click(function() {
          var onum = $('#num').val();
        var onome = $('#nome').val();
        var oemail = $('#email').val();
        var apassword = $('#password').val();
        var apassword_confirma = $('#password_confirma').val();
            $.ajax({
                url: "login_alterar_actions.php",
                type: "POST",
                data: {
                  userid: user_id,
                  num: onum,
                  nome: onome,
                  email: oemail,
                  password: apassword,
                  password_confirma:apassword_confirma,
                }
            }).done(function(data) {
                //	console.log(data);
                //alert(data);
                //TUDO OK
 
            //Validar Preenchimento obrigatório
            if (data == 0) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Todos os campos são de preenchimento obrigatório. Por favor, complete o formulário!</div>'
                );
            }
            if (data == 1) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Já um ultilizador com o mesmo número mecanográfico.</div>'
                );
            }
            if (data == 2) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Já um ultilizador com o mesmo nome.</div>'
                );
            }
            if (data == 3) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Já um ultilizador com o mesmo e-mail.</div>'
                );
            }
            if (data == 12) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Já um ultilizador com o mesmo número mecanográfico e o mesmo nome.</div>'
                );
            }
            if (data == 13) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Já um ultilizador com o mesmo número mecanográfico e mesmo email.</div>'
                );
            }
            if (data == 23) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Já um ultilizador com o mesmo número mecanográfico e mesmo email.</div>'
                );
            }
            if (data == 5) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Os emails precisam ser terminados com o domínio <strong>@cm-espinho.pt</strong></div>'
                );
                $('#Terminar Registo').prop('disabled', true);
            }
            if (data == 6) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">A password tem que ter pelo menus 8 carateres.</div>'
                );
                $('#Terminar Registo').prop('disabled', true);
            }
            if (data == 7) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">A password deve conter letras e números.</div>'
                );
                $('#Terminar Registo').prop('disabled', true);
            }
            if (data == 8) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">A password não coincide com a password de confirmação</div>'
                );
                $('#Terminar Registo').prop('disabled', true);
            }


            if (data == 58) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">Os emails precisam ser terminados com o domínio <strong>@cm-espinho.pt</strong> e a password não coincide com a password de confirmação.</div>'
                );
                $('#Terminar Registo').prop('disabled', true);
            }
            if (data == 69) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-danger alert-dismissible show" role="alert">A password deve de ser alfanumérica (ter pelo menos 2 números).</div>'
                );
                $('#Terminar Registo').prop('disabled', true);
            }
            //TUDO OK
            if (data == 9) //Existe
            {
                $('#msg_num_mec').html(
                    '<div id="alert-senha" class="alert alert-success alert-dismissible show" role="alert">O utilizador foi atualizado com sucesso!</div>'
                );
                setTimeout(function() {
                    history.back();
                }, 3000);
                //$('#Terminar Registo').prop('disabled', true);
            }
            }).fail(function(jqXHR, textStatus) {
                console.log("Request failed: " + textStatus);
            });
        });




    });
</script>